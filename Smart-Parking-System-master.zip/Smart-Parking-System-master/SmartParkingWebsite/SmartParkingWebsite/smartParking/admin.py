
from .models import *


from django.contrib import admin
admin.site.register(timetime)
admin.site.register(Profile)
admin.site.register(slots)
admin.site.register(driver)
admin.site.register(reserves)
