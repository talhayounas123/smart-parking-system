package com.tss.smartparking;

public class SliderItem {
   int id;
   int simgae;

    public SliderItem(int id, int simgae) {
        this.id = id;
        this.simgae = simgae;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSimgae() {
        return simgae;
    }

    public void setSimgae(int simgae) {
        this.simgae = simgae;
    }
}
