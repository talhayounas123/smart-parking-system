package com.tss.smartparking;

public class Constatnt {
    public  static  String MAIN="http://192.168.174.129:8000/";
    public  static  String SHOWALLAPP= "showall/?format=json";
    public  static  String RESEVER= "showall/?format=json";

}
